package com.rentee.rentee;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;

public class PasswordActivity extends AppCompatActivity {
    private EditText premail;
    private Button prbtn;
    private FirebaseAuth auth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_password);
        premail = (EditText)findViewById(R.id.email_pwd);
        prbtn = (Button)findViewById(R.id.button_pwdreset);
        auth = FirebaseAuth.getInstance();
        prbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
            String usremail = premail.getText().toString().trim();
            if(TextUtils.isEmpty(usremail)){
                Toast.makeText(PasswordActivity.this,"Please Enter Email Address",Toast.LENGTH_SHORT).show();
            }else{
                auth.sendPasswordResetEmail(usremail).addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if(task.isSuccessful()){
                            Toast.makeText(PasswordActivity.this,"Password reset email sent",Toast.LENGTH_SHORT).show();
                            finish();
                            startActivity(new Intent(PasswordActivity.this,LoginActivity.class));
                        }else{
                            Toast.makeText(PasswordActivity.this,"Error in sending password reset email",Toast.LENGTH_SHORT).show();
                        }

                    }
                });
            }
            }
        });
    }
}
