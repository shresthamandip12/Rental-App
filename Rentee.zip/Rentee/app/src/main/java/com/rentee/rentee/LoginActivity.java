package com.rentee.rentee;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class LoginActivity extends AppCompatActivity {
    private TextView textView_reg;
    private EditText login_email;
    private EditText login_pwd;
    private Button lbtn;
    private TextView txt;
    FirebaseAuth auth1;

    private ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        textView_reg = (TextView)findViewById(R.id.signup1);
        login_email = (EditText)findViewById(R.id.email);
        login_pwd = (EditText) findViewById(R.id.lgn_pwd);
        lbtn = (Button) findViewById(R.id.button_lgn);
        txt = (TextView) findViewById(R.id.fgtpwd);
        auth1 =  FirebaseAuth.getInstance();
        progressDialog = new ProgressDialog(this);
        txt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(LoginActivity.this,PasswordActivity.class));
            }
        });
        textView_reg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent regintent = new Intent(LoginActivity.this,SignUPActivity.class);
                        startActivity(regintent);

            }
        });
        lbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
            validate(login_email.getText().toString().trim(),login_pwd.getText().toString().trim());

            }
        });


    }
    private  void validate(String userName , String userPassword){
        progressDialog.setMessage("Logging In");
        progressDialog.show();
        auth1.signInWithEmailAndPassword(userName, userPassword).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if(task.isSuccessful()){
                    progressDialog.dismiss();
                    checkVerificationEmail();
                }else{
                    progressDialog.dismiss();
                    Toast.makeText(LoginActivity.this,"Login Failed",Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
    private void checkVerificationEmail(){
        FirebaseUser firebaseUser = auth1.getInstance().getCurrentUser();
        Boolean emailflag = firebaseUser.isEmailVerified();
        if(emailflag){
            finish();
            startActivity(new Intent(LoginActivity.this,MainActivity.class));

        }else{
            Toast.makeText(LoginActivity.this,"Verify Email",Toast.LENGTH_SHORT).show();
            auth1.signOut();
        }

    }

}
