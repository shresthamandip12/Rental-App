package com.rentee.rentee;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class SignUPActivity extends AppCompatActivity {
private EditText rfnme,reml,rpwd,rcpwd;
private Button regbtn;
private FirebaseAuth fba;
private TextView txt;
private ProgressDialog progressDialog;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);
        rfnme = (EditText)findViewById(R.id.fname);
        reml = (EditText)findViewById(R.id.reg_email);
        rpwd = (EditText)findViewById(R.id.register_pwd1);
        rcpwd =(EditText)findViewById(R.id.register_pwd2);
        regbtn = (Button)findViewById(R.id.button_reg);
        txt = (TextView) findViewById(R.id.alrdyac);
        fba = FirebaseAuth.getInstance();
        progressDialog = new ProgressDialog(this);
        txt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(SignUPActivity.this,LoginActivity.class));
            }
        });
        regbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String fname = rfnme.getText().toString().trim();
                String remail = reml.getText().toString().trim();
                String rpassword = rpwd.getText().toString().trim();
                String rcpassword = rcpwd.getText().toString().trim();
                if(TextUtils.isEmpty(remail)){
                    Toast.makeText(SignUPActivity.this,"Please Enter Email",Toast.LENGTH_SHORT).show();
                    return;
                }
                if(TextUtils.isEmpty(fname)){
                    Toast.makeText(SignUPActivity.this,"Please Enter Name",Toast.LENGTH_SHORT).show();
                    return;
                }
                if(TextUtils.isEmpty(rpassword)){
                    Toast.makeText(SignUPActivity.this,"Please Enter Password",Toast.LENGTH_SHORT).show();
                    return;
                }
                if(TextUtils.isEmpty(rcpassword)){
                    Toast.makeText(SignUPActivity.this,"Please Enter Confirm Password",Toast.LENGTH_SHORT).show();
                    return;
                }
                if(rpassword.length()<6){
                Toast.makeText(SignUPActivity.this,"Too Short",Toast.LENGTH_SHORT).show();
                }
                if(rpassword.equals(rcpassword)){
                    progressDialog.setMessage("Signing Up");
                    progressDialog.show();
                fba.createUserWithEmailAndPassword(remail,rpassword).addOnCompleteListener(SignUPActivity.this,new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                    if(task.isSuccessful()){
                        progressDialog.dismiss();
                        sendEmailVerification();
                    }else{
                        progressDialog.dismiss();
                        Toast.makeText(SignUPActivity.this,"Registration Failed",Toast.LENGTH_SHORT).show();
                    }
                    }
                });

                }else{
                    progressDialog.dismiss();
                    Toast.makeText(SignUPActivity.this,"Password Mismatched",Toast.LENGTH_SHORT).show();
                }


            }

        });
    }
    private void  sendEmailVerification(){
        FirebaseUser firebaseUser = fba.getCurrentUser();
        if(firebaseUser != null){
            firebaseUser.sendEmailVerification().addOnCompleteListener(new OnCompleteListener<Void>() {
                @Override
                public void onComplete(@NonNull Task<Void> task) {
                if(task.isSuccessful()){
                    Toast.makeText(SignUPActivity.this,"Sucessfully Register,Verification Mail Has been sent.",Toast.LENGTH_SHORT).show();
                  fba.signOut();
                  finish();
                  startActivity(new Intent(SignUPActivity.this,LoginActivity.class));
                }else {
                    Toast.makeText(SignUPActivity.this,"Verification Mail Has not  been sent.",Toast.LENGTH_SHORT).show();
                }
                }
            });
        }

    }
}
